print("Safi ur Rehman 24K-0031")

class Drone:
    def __init__(self, drone_id, max_payload, speed):
        self.id = drone_id
        self.max_payload = max_payload
        self.speed = speed
        self.location = (0,0)
        self.available = True

    def assign(self, package):
        if package.weight <= self.max_payload and self.available:
            self.available = False
            return True
        return False

    def deliver(self, package):
        self.location = package.destination
        self.available = True
        return True

class Package:
    def __init__(self, pkg_id, weight, destination):
        self.id = pkg_id
        self.weight = weight
        self.destination = destination

drones = [Drone('D1', 5, 60), Drone('D2', 2, 40)]
packages = [Package('P1', 1, (5,5)), Package('P2', 3, (2,8)), Package('P3', 6, (1,1))]

def schedule_deliveries(drones, packages):
    report = []
    for pkg in packages:
        assigned = False
        for d in drones:
            if d.assign(pkg):
                d.deliver(pkg)
                report.append((pkg.id, d.id, 'Delivered'))
                assigned = True
                break
        if not assigned:
            report.append((pkg.id, None, 'No available drone or overweight'))
    return report

report = schedule_deliveries(drones, packages)
print()
print("LahoreLogistics delivery report:")
for r in report:
    print(r[0], "-", (r[1] if r[1] else 'None'), "-", r[2])
