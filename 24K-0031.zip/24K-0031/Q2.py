print("Safi ur Rehman 24K-0031")

posts = [
    "I love my new GoUPhone, the battery life is amazing",
    "Terrible customer service, waiting for days and no response",
    "Good value for money, camera is decent",
    "Worst experience ever, phone overheats and lags",
    "Happy with the purchase, fast and reliable"
]

positive_words = {'love','amazing','good','great','happy','fast','reliable','decent','excellent','awesome'}
negative_words = {'terrible','worst','bad','overheats','lags','waiting','slow','disappointing'}

def analyze_sentiment(text):
    words = text.lower().replace('.', '').replace(',', '').split()
    score = 0
    for w in words:
        if w in positive_words:
            score += 1
        if w in negative_words:
            score -= 1
    if score > 0:
        return 'Positive'
    if score < 0:
        return 'Negative'
    return 'Neutral'

results = []
for p in posts:
    s = analyze_sentiment(p)
    results.append((p, s))

print()
print("GoUPhone sentiment analysis:")
for text, sentiment in results:
    print("-", sentiment, ":", text)
