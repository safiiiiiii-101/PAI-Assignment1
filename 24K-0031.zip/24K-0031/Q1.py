print("Safi ur Rehman 24K-0031")

transactionLog = [
    {'orderId': 1001, 'customerId': 'cust_Ahmed', 'productId': 'prod_10'},
    {'orderId': 1002, 'customerId': 'cust_Ahmed', 'productId': 'prod_12'},
    {'orderId': 1003, 'customerId': 'cust_Bisma', 'productId': 'prod_10'},
    {'orderId': 1003, 'customerId': 'cust_Bisma', 'productId': 'prod_15'},
    {'orderId': 1004, 'customerId': 'cust_Ahmed', 'productId': 'prod_15'},
    {'orderId': 1005, 'customerId': 'cust_Afzal', 'productId': 'prod_17'},
    {'orderId': 1006, 'customerId': 'cust_Faisal', 'productId': 'prod_10'}
]

productCatalog = {
    'prod_10': 'Wireless Mouse',
    'prod_12': 'Keyboard',
    'prod_15': 'USB-C Hub',
    'prod_17': 'Monitor'
}

def processTransactions(transactionsList):
    data = {}
    for t in transactionsList:
        c = t['customerId']
        p = t['productId']
        if c not in data:
            data[c] = set()
        data[c].add(p)
    return data

def findFrequentPairs(customerData):
    pairs = {}
    for products in customerData.values():
        items = list(products)
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                pair = tuple(sorted((items[i], items[j])))
                pairs[pair] = pairs.get(pair, 0) + 1
    return pairs

def getRecommendations(targetProductId, frequentPairs):
    recs = {}
    for (a, b), count in frequentPairs.items():
        if a == targetProductId:
            recs[b] = count
        elif b == targetProductId:
            recs[a] = count
    return sorted(recs.items(), key=lambda x: x[1], reverse=True)

customerData = processTransactions(transactionLog)
frequentPairs = findFrequentPairs(customerData)
target = 'prod_10'
recs = getRecommendations(target, frequentPairs)
print()
print("Recommendations for", productCatalog[target])
for i, (prod, freq) in enumerate(recs, start=1):
    print(f"{i}. {productCatalog[prod]} (bought together {freq} times)")
