import numpy as np

with open("sensor_data.csv", "r") as f:
    lines = f.readlines()

data = np.array([row.strip().split(",") for row in lines])

data[data == "-999"] = np.nan
data = data.astype(float)
data[(data < 0) | (data > 100)] = np.nan

print("Safi ur Rehman 24K-0031")

avg_sensor = np.nanmean(data, axis=0)
print("Average values per sensor:", avg_sensor[:5])

median_hourly = np.nanmedian(data, axis=1)
print("Hourly median readings (first 5):", median_hourly[:5])

missing = np.isnan(data).sum(axis=0)
worst_sensor = np.argmax(missing)

print("Sensor with highest missing values:", worst_sensor)
print("Missing count for this sensor:", missing[worst_sensor])

xmin = np.nanmin(data)
xmax = np.nanmax(data)

normalized = (data - xmin) / (xmax - xmin)

print("Normalized first 5 rows:")
print(normalized[:5])

np.savetxt("normalized_sensor_output.csv", normalized, delimiter=",")
