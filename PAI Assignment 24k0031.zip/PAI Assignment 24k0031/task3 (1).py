import pandas as pd

data = pd.read_csv("Titanic-Dataset.csv")
data.info()

data['Age'] = data['Age'].fillna(data.groupby(['Pclass', 'Sex'])['Age'].transform('median'))
data['Embarked'] = data['Embarked'].fillna(data['Embarked'].mode()[0])
data.drop(columns=['Cabin'], inplace=True)

data.insert(10, "FamilySize", data['SibSp'] + data['Parch'])
data['IsAlone'] = 0
data.loc[data['FamilySize'] == 0, 'IsAlone'] = 1

data['Age'] = data['Age'].astype('int64')

data.to_csv("titanic_cleaned.csv", index=False)

print("Safi Ur Rehman 24K-0031")
