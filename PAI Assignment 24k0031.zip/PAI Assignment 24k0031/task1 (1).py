import requests

print("Safi ur Rehman 24K-0031")

API_KEY = "16c46649-506f-44d8-978b-3cc74dcbc943"
API_URL = f"https://api.cricapi.com/v1/currentMatches?apikey={API_KEY}"

def fetch_matches(url):
    try:
        r = requests.get(url)
        if r.status_code != 200:
            print("Error:", r.status_code)
            print("Response:", r.text)
            return None
        return r.json()
    except requests.exceptions.RequestException as e:
        print("Network error:", e)
        return None

def show_api_status(data):
    if not data:
        print("No API data")
        return
    for k, v in data.items():
        if k not in ("data", "apikey"):
            print(f"{k}: {v}")

def match_info(url):
    try:
        r = requests.get(url)
        if r.status_code != 200:
            print("Fetch error:", r.status_code)
            return

        info = r.json()
        if info.get("status") != "success" or not info.get("data"):
            print("No live matches available.")
            return

        for m in info["data"]:
            print("Match:", m.get("name", "N/A"))
            print("Status:", m.get("status", "N/A"))
            print("Venue:", m.get("venue", "N/A"))
            print("Date :", m.get("date", "N/A"))
            print("-" * 30)

            scores = m.get("score", [])
            if not scores:
                print("No score details.\n" + "-" * 30)
                continue

            print("Score Details:")
            for s in scores:
                print(" Inning :", s.get("inning", "N/A"))
                print(" Runs   :", s.get("r", "N/A"))
                print(" Wickets:", s.get("w", "N/A"))
                print(" Overs  :", s.get("o", "N/A"))
                print(" " + "-" * 25)

    except requests.exceptions.RequestException as e:
        print("Network error:", e)

data = fetch_matches(API_URL)
print("API URL:", API_URL)

if data:
    show_api_status(data)
    match_info(API_URL)
else:
    print("Unable to retrieve data.")
