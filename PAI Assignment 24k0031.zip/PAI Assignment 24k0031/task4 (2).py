import pandas as pd

df1 = pd.read_csv("titanic_cleaned.csv")
df2 = pd.read_csv("ticket_fares.csv")
df3 = pd.merge(df1, df2, on='Ticket')

age_labels = ['Child', 'Teen', 'Adult', 'Senior']
age_bins = [0, 16, 25, 50, 100]
df3['AgeGroup'] = pd.cut(df3['Age'], bins=age_bins, labels=age_labels, right=True)

survival_rate = df3.groupby(['Sex', 'AgeGroup'], observed=True)['Survived'].mean()
print(survival_rate)

with open('report.txt', 'w') as f:
    f.write(
        "The analysis shows that women and children had higher survival rate than men. "
        "The survival rate of women ranges from 47.8% for children to 93.3% for seniors. "
        "For men, the survival rate ranges from 10% for seniors to 25.3% for children. "
        "Female children had the lowest survival rate among females, while among males, "
        "children had the highest survival rate. The data supports the 'women first' "
        "hypothesis but does not support 'children first' within the female group."
    )

class_survival = df3.groupby("Pclass")['Survived'].mean()
print(class_survival)

fare_labels = ['Low', 'Medium', 'High', 'Very High']
df3['FareBin'] = pd.qcut(df3['Fare_x'], 4, labels=fare_labels)

fare_survival = df3.groupby('FareBin', observed=True)['Survived'].mean()
print(fare_survival)

with open('report.txt', 'a') as f:
    f.write(
        " The data supports the wealth hypothesis. Survival increases across passenger classes, "
        "ranging from 23.9% in class 3 to 68.9% in class 1. Similarly, survival by fare groups "
        "ranges from 22.9% for low fare to 60.9% for high fare, showing that higher fare correlates "
        "with increased survival probability."
    )

print("Safi Ur Rehman 24K-0031")
